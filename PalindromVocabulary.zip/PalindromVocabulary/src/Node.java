public class Node {
    char harf;
    Node next;

    public Node(char harf) {
        this.harf = harf;
    }
}
